
public class Vertex
{
	public int x;
	public int y;
	
	public Vertex(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
}
