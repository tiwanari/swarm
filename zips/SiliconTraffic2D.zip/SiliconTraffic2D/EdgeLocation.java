
public class EdgeLocation
{
	public Edge m_edge;
	public int  m_edgeRelativeLocation;
	
	public EdgeLocation( Edge edge, int edgeRelativeLocation )
	{
		m_edge = edge;
		m_edgeRelativeLocation = edgeRelativeLocation;
	}
}
